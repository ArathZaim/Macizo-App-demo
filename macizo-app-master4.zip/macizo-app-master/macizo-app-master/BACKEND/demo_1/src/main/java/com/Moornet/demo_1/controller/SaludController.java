package com.Moornet.demo_1.controller;


import com.Moornet.demo_1.entity.Salud;
import com.Moornet.demo_1.entity.Usuario;
import com.Moornet.demo_1.service.SaludService;
import com.Moornet.demo_1.service.UsuarioService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;


@RequestMapping("/macizoapp/salud")
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@AllArgsConstructor
public class SaludController {
  private final SaludService saludService;

  @Autowired
  private UsuarioService usuarioser;


  @GetMapping("T")
  public Iterable<Salud> getSaludList() {
    return saludService.getTodaLaSalud();
  }

  @ResponseStatus(HttpStatus.CREATED)
  @PostMapping
  public Salud nuevaSalud(@RequestBody Salud nuevaSalud) throws Exception {
    return saludService.guardarSalud(nuevaSalud);
  }

  @GetMapping("buscarS/{id_usuario_frg}")
  public Salud getI(@PathVariable("id_usuario_frg") Integer id_usuario_frg) throws Exception {
    return saludService.findById(id_usuario_frg);
  }


  @GetMapping("usuarioIS/{id_usuario_frg}")
  public Salud getSaludporUsuario(@PathVariable Integer id_usuario_frg) throws Exception {
    return saludService.encontrarIdUsuarioSalud(id_usuario_frg);
  }

  @GetMapping("buscarU/{id_usuario_frg}")
  public Usuario getUsalud(@PathVariable("id_usuario_frg") Integer id_usuario_frg) throws Exception {
    return usuarioser.findById(id_usuario_frg);
  }


  @PutMapping("actualizar/{id}")
  public Salud updateSalud(@PathVariable Integer id_salud, @RequestBody Salud salud) throws Exception {
    return saludService.updateSalud(id_salud, salud);
  }
}
