package com.Moornet.demo_1.controller;

import com.Moornet.demo_1.entity.Token;
import com.Moornet.demo_1.entity.Usuario;
import com.Moornet.demo_1.repository.TokenRepository;
import com.Moornet.demo_1.service.MailService;
import com.Moornet.demo_1.service.TokenService;
import com.Moornet.demo_1.service.UsuarioService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Optional;
import java.util.stream.StreamSupport;


@RequestMapping("/macizoapp/usuarios")
@CrossOrigin(origins = "http://localhost:4200")
@RestController

@AllArgsConstructor
public class UserController {


  private final UsuarioService usuarioService;
  private final TokenRepository tokenRepository;
  private final TokenService tokenService;
  private final MailService mailService;
  // private final Salud salud;

  @GetMapping
  public Iterable<Usuario> getUserList() {
    return usuarioService.getAllU();
  }

  @GetMapping("/id/{id}")
  public Usuario getI(@PathVariable Integer id) throws Exception {
    if (id == null) {
      throw new IllegalArgumentException("El ID no puede ser null");
    }
    //salud.setId_usuarioSalud(id);
    System.out.println("Id correcta" + id);

    return usuarioService.findById(id);
  }


  @GetMapping("/email/{email}/password/{password}")
  public ResponseEntity<?> validarUsuario(@PathVariable String email, @PathVariable String password) {
    Iterable<Usuario> usuarios = usuarioService.getAllU();
    Usuario usuarioEncontrado = null;

    for (Usuario usuario1 : usuarios) {
      if (usuario1.getEmail().equals(email)) {
        if (usuario1.getPassword().equals(password)) {
          usuarioEncontrado = new Usuario(
            usuario1.getId_usuario(),
            usuario1.getNombre(),
            usuario1.getEmail(),
            usuario1.getPassword(),
            usuario1.getEdad(),
            usuario1.getObjetivo()
          );
          System.out.println(usuario1.getId_usuario());
          return ResponseEntity.ok(usuarioEncontrado);
        } else {
          return ResponseEntity
            .status(HttpStatus.UNAUTHORIZED)
            .body("Contraseña incorrecta");
        }
      }
    }

    return ResponseEntity
      .status(HttpStatus.NOT_FOUND)
      .body("Usuario no encontrado");
  }


  @ResponseStatus(HttpStatus.CREATED)
  @PostMapping
  public Usuario newUser(@RequestBody Usuario user) throws Exception {
    Iterable<Usuario> usuarios = usuarioService.getAllU();
    return usuarioService.saveNewUser(user);
  }

  @PutMapping("{id}")
  public Usuario updateUser(@PathVariable Integer id_usuario, @RequestBody Usuario user) throws Exception {
    return usuarioService.updateUser(id_usuario, user);
  }


  /*
  *
      Usuario usuarioEncontrado = null;

    for (Usuario usuario1 : usuarios) {
      if (usuario1.getEmail().equals(user.getEmail())) {
        throw new IllegalArgumentException("ESTE USUARIO YA ESTA REGISTRADO");

      }
    }

  * */

  @GetMapping("/existenciaU/{email}")
  public ResponseEntity<?> existenciaU(@PathVariable String email) throws Exception {
    //salud.setId_usuarioSalud(id);
    Usuario usuarioEncontrado = null;
    Iterable<Usuario> usuarios = usuarioService.getAllU();

    for (Usuario usuario1 : usuarios) {
      if (usuario1.getEmail().equals(email)) {
        throw new IllegalArgumentException("ESTE USUARIO YA ESTA REGISTRADO");
      }
    }
    return ResponseEntity.ok(Map.of("message", "USUARIO CREADO."));

  }


  @PostMapping("/password-reset/request")
  public ResponseEntity<?> solicitarCambioContraseña(@RequestBody String email) {

    // Buscar usuario por correo
    Usuario usuario = StreamSupport.stream(usuarioService.getAllU().spliterator(), false)
      .filter(u -> u.getEmail().equals(email))
      .findFirst()
      .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Correo no registrado."));

    // Generar y guardar token

    Token resetToken = tokenService.createToken(usuario);

    mailService.sendPasswordResetEmail(usuario.getEmail(), resetToken.getToken());

    return ResponseEntity.ok(Map.of("message", "Correo enviado."));
  }

  private void guardarTokenDeReset(Usuario usuario, String token) {
    Token resetToken = new Token(token, usuario, LocalDateTime.now());
    resetToken.setToken(token);
    resetToken.setUsuario(usuario);
    resetToken.setExpirationDate(LocalDateTime.now().plusHours(1)); // Expira en 1 hora
    tokenRepository.save(resetToken);
  }


  @PostMapping("/password-reset/confirm")
  public ResponseEntity<?> confirmarCambioContraseña(@RequestBody Map<String, String> request) {
    String token = request.get("token");
    String nuevaContraseña = request.get("password");

    Optional<Token> resetToken = tokenService.findByToken(token);


    Usuario usuario = resetToken.get().getUsuario();
    usuario.setPassword(nuevaContraseña);
    usuarioService.saveNewUser(usuario);

    // Eliminar token después del uso
    tokenService.deleteExpiredTokens(resetToken);
    return ResponseEntity.ok("Contraseña actualizada correctamente.");
  }


}
