package com.Moornet.demo_1.entity;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Token {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String token;

  @OneToOne
  @JoinColumn(name = "user_id", referencedColumnName = "id_usuario")
  private Usuario usuario;

  private LocalDateTime expirationDate;


  public Token(String token, Usuario usuario, LocalDateTime expirationDate) {
    this.token = token;
    this.usuario = usuario;
    this.expirationDate = expirationDate;
  }

  // Getters y Setters
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getToken() {
    return token;
  }

  public void setToken(String token) {
    this.token = token;
  }

  public Usuario getUsuario() {
    return usuario;
  }

  public void setUsuario(Usuario usuario) {
    this.usuario = usuario;
  }

  public LocalDateTime getExpirationDate() {
    return expirationDate;
  }

  public void setExpirationDate(LocalDateTime expirationDate) {
    this.expirationDate = expirationDate;
  }
}
