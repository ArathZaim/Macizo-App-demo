package com.Moornet.demo_1.repository;

import com.Moornet.demo_1.entity.Salud;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface SaludRepository extends CrudRepository<Salud, Integer> {

  @Query("SELECT s FROM Salud s WHERE s.id_usuario_frg.id_usuario = :id_usuario_frg")
  Salud encontrarUsuarioS(@Param("id_usuario_frg") Integer id_usuario_frg);

}
