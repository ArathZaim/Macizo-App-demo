package com.Moornet.demo_1.service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailService {

  private final JavaMailSender mailSender;

  // Inyección de dependencia del mailSender
  public MailService(JavaMailSender mailSender) {
    this.mailSender = mailSender;
  }

  public void sendPasswordResetEmail(String email, String token) {
    String link = "http://localhost:4200/reset-password?token=" + token;
    String mensaje = "Haz clic en el siguiente enlace para cambiar tu contraseña: " + link;

    SimpleMailMessage emailMessage = new SimpleMailMessage();
    emailMessage.setTo(email);
    emailMessage.setSubject("Cambio de contraseña");
    emailMessage.setText(mensaje);
    emailMessage.setFrom("arathsaim@hotmail.com");

    // Envío del correo
    mailSender.send(emailMessage);
  }
}

