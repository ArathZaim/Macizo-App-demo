package com.Moornet.demo_1.service;

import com.Moornet.demo_1.entity.Token;
import com.Moornet.demo_1.entity.Usuario;
import com.Moornet.demo_1.repository.TokenRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
public class TokenService {

  private final TokenRepository tokenRepository;

  public TokenService(TokenRepository tokenRepository) {
    this.tokenRepository = tokenRepository;
  }

  public Optional<Token> findByToken(String token){
    return tokenRepository.findByToken(token);
  }

  public Token createToken(Usuario usuario) {
    String token = UUID.randomUUID().toString();
    Token resetToken = new Token(token, usuario, LocalDateTime.now().plusHours(1));
    return tokenRepository.save(resetToken);
  }

  public Optional<Token> validateToken(String token) {
    Optional<Token> resetToken = tokenRepository.findByToken(token);
    if (resetToken.isPresent() && resetToken.get().getExpirationDate().isAfter(LocalDateTime.now())) {
      return resetToken;
    }
    return Optional.empty();
  }

  public void deleteExpiredTokens(Optional<Token> resetToken) {
    tokenRepository.deleteByExpirationDateBefore(LocalDateTime.now());
  }
}
