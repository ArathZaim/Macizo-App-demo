package com.Moornet.demo_1.controller;

import com.Moornet.demo_1.entity.Usuario;
import com.Moornet.demo_1.service.UsuarioService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RequestMapping("/macizoapp/usuarios")
@CrossOrigin(origins = "http://localhost:4200")
@RestController

@AllArgsConstructor
public class UserController {


  private final UsuarioService usuarioService;

  @GetMapping
  public Iterable<Usuario> getUserList() {
    return usuarioService.getAllU();
  }

  @GetMapping("/id/{id}")
  public Usuario getI(@PathVariable Integer id) throws Exception {
    if (id == null) {
      throw new IllegalArgumentException("El ID no puede ser null");
    }
    System.out.println("Id correcta" + id);
    return usuarioService.findById(id);
  }


  @GetMapping("/email/{email}/password/{password}")
  public ResponseEntity<?> validarUsuario(@PathVariable String email, @PathVariable String password) {
    Iterable<Usuario> usuarios = usuarioService.getAllU();
    Usuario usuarioEncontrado = null;

    for (Usuario usuario1 : usuarios) {
      if (usuario1.getEmail().equals(email)) {
        if (usuario1.getPassword().equals(password)) {
          usuarioEncontrado = new Usuario(
            usuario1.getNombre(),
            usuario1.getEmail(),
            usuario1.getPassword(),
            usuario1.getEdad(),
            usuario1.getObjetivo()
          );
          return ResponseEntity.ok(usuarioEncontrado);
        } else {
          return ResponseEntity
            .status(HttpStatus.UNAUTHORIZED)
            .body("Contraseña incorrecta");
        }
      }
    }

    return ResponseEntity
      .status(HttpStatus.NOT_FOUND)
      .body("Usuario no encontrado");
  }


  @ResponseStatus(HttpStatus.CREATED)
  @PostMapping
  public Usuario newUser(@RequestBody Usuario user) {
    return usuarioService.saveNewUser(user);
  }

  @PutMapping("{id}")
  public Usuario updateUser(@PathVariable Integer id_usuario, @RequestBody Usuario user) throws Exception {
    return usuarioService.updateUser(id_usuario, user);
  }

}
