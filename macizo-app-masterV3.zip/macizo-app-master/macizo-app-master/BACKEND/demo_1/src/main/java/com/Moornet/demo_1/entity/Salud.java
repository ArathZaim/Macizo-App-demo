package com.Moornet.demo_1.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@RequiredArgsConstructor
@NoArgsConstructor
public class Salud {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private int id_Salud;

  @NonNull
  @ManyToOne
  @JoinColumn(name = "id_usuario_frg", referencedColumnName = "id_usuario")
  @JsonBackReference
  private Usuario id_usuario_frg;

  @NonNull
  @Column(name = "peso")
  private float peso;

  @NonNull
  @Column(name = "altura")
  private float altura;

  @NonNull
  @Column(name = "imc")
  private float imc;


}
