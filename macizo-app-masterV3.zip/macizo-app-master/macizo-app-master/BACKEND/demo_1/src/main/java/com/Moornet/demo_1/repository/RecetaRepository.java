package com.Moornet.demo_1.repository;

import org.springframework.data.repository.CrudRepository;
import com.Moornet.demo_1.entity.Receta;

public interface RecetaRepository extends CrudRepository<Receta,Integer> {

}
