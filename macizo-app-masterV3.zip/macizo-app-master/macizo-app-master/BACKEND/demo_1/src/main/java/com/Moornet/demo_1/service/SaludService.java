package com.Moornet.demo_1.service;

import com.Moornet.demo_1.entity.Salud;
import com.Moornet.demo_1.entity.Usuario;
import com.Moornet.demo_1.repository.SaludRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor

public class SaludService {
  private final SaludRepository saludRepository;

  public Iterable<Salud> getTodaLaSalud(){
    return saludRepository.findAll();
  }
  public Salud guardarSalud(Salud nuevaSalud){
    return saludRepository.save(nuevaSalud);
  }

  public Salud findById(Integer idU) throws Exception {

    return saludRepository.findById(idU).orElseThrow(Exception::new);
  }


  public Salud updateSalud(Integer idu, Salud salud) throws Exception {
    Salud salud1=findById(idu);
    return saludRepository.save(salud1);

  }






}
