package com.Moornet.demo_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Moornet1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
